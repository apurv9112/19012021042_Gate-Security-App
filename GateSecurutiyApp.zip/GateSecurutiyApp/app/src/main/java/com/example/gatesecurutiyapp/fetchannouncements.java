package com.example.gatesecurutiyapp;

public class fetchannouncements
{
    String announcements;

    public fetchannouncements(){}

    public fetchannouncements(String announcements) {
        this.announcements = announcements;
    }

    public String getAnnouncements() {
        return announcements;
    }

    public void setAnnouncements(String announcements) {
        this.announcements = announcements;
    }
}
